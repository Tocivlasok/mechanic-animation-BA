"""
Created on Sat May 23 13:47:32 2020.

@author: Tocivlasok

@directory: mechanic_animation/tests/
"""
