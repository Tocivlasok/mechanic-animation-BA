"""
Created on Sun May 31 17:47:05 2020.

@author: Tocivlasok

@directory: mechanic_animation/string_funcs
"""
